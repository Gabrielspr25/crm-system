import{r,g as t}from"./vendor-Bzgz95E1.js";var a=r();const o=t(a);export{o as R,a as r};
