export const APP_VERSION = 'v5.2.6-BACKEND-FIX';
export const BUILD_LABEL = "PRODUCTION FINAL";
