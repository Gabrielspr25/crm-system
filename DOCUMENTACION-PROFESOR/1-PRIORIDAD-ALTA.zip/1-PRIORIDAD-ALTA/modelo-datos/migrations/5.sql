
ALTER TABLE subscribers ADD COLUMN remaining_payments INTEGER DEFAULT 0;
