
DROP TABLE follow_up_prospects;
DROP TABLE call_logs;
DROP TABLE follow_up_steps;
DROP TABLE priorities;