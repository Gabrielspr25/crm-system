SELECT id, business_name, created_at FROM clients WHERE business_name ILIKE '%TECH WEB%';
SELECT id, ban_number, status FROM bans WHERE ban_number = '841786385';