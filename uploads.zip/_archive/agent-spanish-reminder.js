
console.log('\n🇪🇸 RECORDATORIO DEL AGENTE: MODO ESPAÑOL ACTIVADO');
console.log('=========================================');
console.log('⚠️  INSTRUCCIÓN CRÍTICA: El Asistente IA debe hablar en ESPAÑOL.');
console.log('⚠️  PREFERENCIA DEL USUARIO: Solo idioma Español.');
console.log('=========================================\n');
