SELECT * FROM users_auth WHERE username='admin';
