SELECT ban_number, account_type FROM bans WHERE ban_number = '777777777';
