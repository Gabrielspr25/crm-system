SELECT username, password_hash FROM users_auth WHERE username='admin';
