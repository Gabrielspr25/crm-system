-- Borrar usuario carlos creado por error
DELETE FROM users_auth WHERE username = 'carlos';
DELETE FROM salespeople WHERE name = 'Carlos López';
