SELECT * FROM salespeople LIMIT 1;
