export const APP_VERSION = "2026-137";
export const BUILD_LABEL = "v2026-135 - Vendedores: crear con Usuario/Contraseña + validación en Estado Sistema";
