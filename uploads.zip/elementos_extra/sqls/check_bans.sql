\d bans
