\d users_auth
SELECT * FROM users_auth LIMIT 5;
SELECT count(*) FROM users_auth;
\dt
