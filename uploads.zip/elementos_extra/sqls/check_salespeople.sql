SELECT * FROM salespeople LIMIT 10;
