SELECT username, salesperson_id FROM users_auth LIMIT 3;
