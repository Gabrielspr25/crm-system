UPDATE referidos 
SET suscriptor = '4258527250',
    modelo = 'VMOV5G15',
    fecha = '2025-12-22',
    notas = notas || ' - Datos recuperados manualmente.'
WHERE id = 4;
