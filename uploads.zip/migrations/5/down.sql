
ALTER TABLE subscribers DROP COLUMN remaining_payments;
