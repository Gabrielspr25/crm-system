
DROP INDEX idx_follow_up_tasks_status;
DROP INDEX idx_follow_up_tasks_subscriber_id;
DROP INDEX idx_subscribers_contract_end_date;
DROP INDEX idx_subscribers_phone;
DROP INDEX idx_subscribers_ban_id;
DROP INDEX idx_bans_ban_number;
DROP INDEX idx_bans_client_id;
DROP INDEX idx_clients_is_active;
DROP INDEX idx_clients_vendor_id;
DROP TABLE follow_up_tasks;
DROP TABLE subscribers;
DROP TABLE bans;
DROP TABLE clients;
DROP TABLE vendors;
