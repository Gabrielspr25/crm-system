
DROP INDEX idx_vendor_product_goals_lookup;
DROP INDEX idx_product_goals_period;
DROP TABLE vendor_product_goals;
DROP TABLE product_goals;
