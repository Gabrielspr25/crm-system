
ALTER TABLE subscribers ADD COLUMN months INTEGER;
