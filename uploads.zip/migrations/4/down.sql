
ALTER TABLE subscribers DROP COLUMN months;
