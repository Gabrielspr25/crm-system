SELECT c.id, c.name 
FROM clients c 
WHERE c.id IN (
  '2bb1a9ed-4eb8-4aa6-ab77-b188285e2b24',
  '57fe11af-55d2-4c26-b85e-2b767ae20cda',
  '6f4ff677-c8b5-4e1a-8dc0-84f1ec4cf9f3'
);
