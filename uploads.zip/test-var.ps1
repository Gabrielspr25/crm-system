$TestVar = "Hello World"
Write-Host "TestVar is $TestVar"
