UPDATE users_auth SET password = '$2b$10$wfbTWSlDvr9eCrAlqBNKBewEZFIsjM8JqgarRxILm0PFHzdL7Hs22' WHERE username = 'admin';
