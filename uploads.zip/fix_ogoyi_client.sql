UPDATE clients 
SET email = 'INFO@OGOYI.COM',
    city = 'CATANEO',
    phone = '4258527250',
    updated_at = NOW()
WHERE id = 29767;