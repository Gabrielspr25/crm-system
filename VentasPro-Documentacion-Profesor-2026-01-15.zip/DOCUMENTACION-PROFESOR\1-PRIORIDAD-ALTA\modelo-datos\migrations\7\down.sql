
ALTER TABLE goals DROP COLUMN product_id;
