
DROP INDEX idx_products_category;
DROP INDEX idx_goals_vendor_period;
DROP TABLE products;
DROP TABLE categories;
DROP TABLE goals;
